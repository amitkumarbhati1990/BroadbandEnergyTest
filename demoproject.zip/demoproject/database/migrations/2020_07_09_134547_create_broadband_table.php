<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBroadbandTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return voidcrea
     */
    public function up()
    {
        Schema::create('broadband', function (Blueprint $table) {
            $table->increments('id', true);
            $table->string('providername', 60);
            $table->string('product', 60);
            $table->float('monthlyprice', 60);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('broadband');
    }
}
