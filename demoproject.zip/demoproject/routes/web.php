<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::resource('/broadband', 'BroadbandController');
Route::get('broadband/create',        [ 'as'=>'broadband.create',       'uses' => 'BroadbandController@create']);
Route::post('broadband/store',        [ 'as'=>'broadband.store',        'uses' => 'BroadbandController@store']);
Route::post('broadband/search', 'BroadbandController@search')->name('broadband.search');


Route::resource('/energy', 'EnergyController');
Route::get('energy/create',        [ 'as'=>'energy.create',       'uses' => 'EnergyController@create']);
Route::post('energy/store',        [ 'as'=>'energy.store',        'uses' => 'EnergyController@store']);
Route::get('energy/edit/{id}',     [ 'as'=>'energy.edit',         'uses' => 'EnergyController@edit']);
Route::post('energy/update/{id}',  [ 'as'=>'energy.update',       'uses' => 'EnergyController@update']);
Route::post('energy/search', 'EnergyController@search')->name('energy.search');
