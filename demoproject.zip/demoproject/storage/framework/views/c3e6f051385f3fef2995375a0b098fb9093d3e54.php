<form  role="form" method="POST" action="<?php echo e(route('energy.store')); ?>">
    <?php echo e(csrf_field()); ?>


    <div class="form-group">
        <input id="providername" type="text" class="form-control"  name="providername" value="<?php echo e(old('providername')); ?>" required autofocus placeholder="provider name">
        <?php if($errors->has('providername')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('providername')); ?></strong>
                                    </span>
        <?php endif; ?>

    </div>

    <div class="form-group">
        <input id="product" type="text" class="form-control" name="product" value="<?php echo e(old('product')); ?>" required placeholder="product">
        <?php if($errors->has('product')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('product')); ?></strong>
                                    </span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <input id="variation" type="text" class="form-control" name="variation" value="<?php echo e(old('variation')); ?>" required placeholder="variation">
        <?php if($errors->has('variation')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('variation')); ?></strong>
                                    </span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <input id="monthlyprice" type="text" class="form-control" name="monthlyprice" value="<?php echo e(old('monthlyprice')); ?>" required placeholder="price">
        <?php if($errors->has('monthlyprice')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('monthlyprice')); ?></strong>
                                    </span>
        <?php endif; ?>
    </div>
    <button type="sumbit" class="btn btn-primary">Save</button>




</form>