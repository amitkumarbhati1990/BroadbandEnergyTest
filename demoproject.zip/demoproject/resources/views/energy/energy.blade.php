<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link href="{{ asset("bootstrap.min.css") }}" rel="stylesheet" type="text/css"/>

    <!-- Styles -->
    <style>
        html, body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway', sans-serif;
            font-weight: 100;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<div class="flex-center position-ref full-height">

    <div class="top-right links">

        <a href="{{ url('/broadband') }}" href="#" data-toggle="modal" data-target="#addDepartment">Broadband</a>

        <a href="{{ url('/energy') }}">Energy</a>


    </div>


    <div class="content">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>Department Name</th>
                <th>Department Code</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>

            </tbody>

        </table>



    </div>
</div>



<!-- Modal -->
<div class="modal fade" id="addDepartment" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Department</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="panel panel-default">
                    <div class="panel-body">

                        <form  role="form" method="POST" action="">
                            {{ csrf_field() }}
                            <div class="row">
                                <div class="col-md-6">
                                    <input id="providername" type="text" class="form-control"  name="providername" value="{{ old('providername') }}" required autofocus placeholder="provider name">


                                </div>

                                <div class="col-md-6">
                                    <input id="product" type="text" class="form-control" name="product" value="{{ old('product') }}" required placeholder="product">
                                </div>
                                <div class="col-md-6">
                                    <input id="variation" type="text" class="form-control" name="variation" value="{{ old('variation') }}" required placeholder="variation">
                                </div>
                                <div class="col-md-6">
                                    <input id="price" type="text" class="form-control" name="price" value="{{ old('price') }}" required placeholder="price">
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="sumbit" class="btn btn-primary">Save Department</button>
                    </div>

                    </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
