

<form  role="form" method="POST" action="{{ route('broadband.store') }}">
                {{ csrf_field() }}

                <div class="form-group">
                    <input id="providername" type="text" class="form-control"  name="providername" value="{{ old('providername') }}" required autofocus placeholder="provider name">
                    @if ($errors->has('providername'))
                        <span class="help-block">
                                        <strong>{{ $errors->first('providername') }}</strong>
                                    </span>
                    @endif

                </div>

                <div class="form-group">
                    <input id="product" type="text" class="form-control" name="product" value="{{ old('product') }}" required placeholder="product">
                    @if ($errors->has('product'))
                        <span class="help-block">
                                        <strong>{{ $errors->first('product') }}</strong>
                                    </span>
                    @endif
                </div>
                <div class="form-group">
                    <input id="monthlyprice" type="text" class="form-control" name="monthlyprice" value="{{ old('monthlyprice') }}" required placeholder="price">
                    @if ($errors->has('monthlyprice'))
                        <span class="help-block">
                                        <strong>{{ $errors->first('monthlyprice') }}</strong>
                                    </span>
                    @endif
                </div>
                <button type="sumbit" class="btn btn-primary">Save</button>




            </form>

