<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Energy;

class EnergyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $energies = Energy::paginate(15);

        return view('energy/index', ['energies' => $energies]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('energy/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        // $input = $request->all();
        // dd( $input); die;
        $this->validateInput($request);
         Energy::create([
             'providername' => $request['providername'],
             'product' => $request['product'],
             'variation' => $request['variation'],
             'monthlyprice' => $request['monthlyprice']
        ]);

        return redirect()->intended('energy')->with('success','Energy Created Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $energy = Energy::find($id);
        // Redirect to Energy list if updating Energy wasn't existed
        if ($energy == null ) {
            return redirect()->intended('energy')
            ->with('error','Energy Update Fail!');
        }

        return view('energy/edit', ['energy' => $energy]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $energy = Energy::findOrFail($id);
        $this->validateInput($request);
        $input = [
            'monthlyprice' => $request['monthlyprice']
        ];
        Energy::where('id', $id)
            ->update($input);
        
        return redirect()->intended('/energy/edit/'.$id.'')->with('success','Energy Updated Successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Energy::where('id', $id)->delete();
         return redirect()->intended('energy')->with('success','Energy Deleted Successfully!');
    }

    /**
     * Search Energy from database base on some specific constraints
     *
     * @param  \Illuminate\Http\Request  $request
     *  @return \Illuminate\Http\Response
     */
    public function search(Request $request) {
        $constraints = [
            'providername' => $request['providername'],
            'product' => $request['product'],
            'variation' => $request['variation']
            ];

       $energies = $this->doSearchingQuery($constraints);
       return view('energy/index', ['energies' => $energies, 'searchingVals' => $constraints]);
    }

    private function doSearchingQuery($constraints) {
        $query = Energy::query();
        $fields = array_keys($constraints);
        $index = 0;
        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $query = $query->where( $fields[$index], 'like', '%'.$constraint.'%');
            }

            $index++;
        }
        return $query->paginate(5);
    }
    private function validateInput($request) {
       // $this->validate($request, [
      //  'variation' => 'required|max:60|unique:energy'
    //]);
    }
    private function createQueryInput($keys, $request) {
        $queryInput = [];
        for($i = 0; $i < sizeof($keys); $i++) {
            $key = $keys[$i];
            $queryInput[$key] = $request[$key];
        }

        return $queryInput;
    }
}
