<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Broadband;

class BroadbandController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $broadbands = Broadband::paginate(15);

        return view('broadband/index', ['broadbands' => $broadbands]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('broadband/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        // $input = $request->all();
        // dd( $input); die;
        $this->validateInput($request);
         Broadband::create([
             'providername' => $request['providername'],
             'product' => $request['product'],
             'monthlyprice' => $request['monthlyprice']
        ]);

        return redirect()->intended('broadband')->with('success','Broadband Created Successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Broadband = Broadband::find($id);
        // Redirect to Broadband list if updating Broadband wasn't existed
        if ($Broadband == null ) {
            return redirect()->intended('broadband')
            ->with('error','Broadband Update Fail!');
        }

        return view('broadband/edit', ['Broadband' => $broadbands]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $Broadband = Broadband::findOrFail($id);
        $this->validateInput($request);
        $input = [
            'providername' => $request['providername'],
            'product' => $request['product'],
            'monthlyprice' => $request['monthlyprice']
        ];
        Broadband::where('id', $id)
            ->update($input);
        
        return redirect()->intended('broadband')->with('success','Broadband Updated Successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Broadband::where('id', $id)->delete();
         return redirect()->intended('broadband')->with('success','Broadband Deleted Successfully!');
    }

    /**
     * Search Broadband from database base on some specific constraints
     *
     * @param  \Illuminate\Http\Request  $request
     *  @return \Illuminate\Http\Response
     */
    public function search(Request $request) {
        $constraints = [
            'providername' => $request['providername'],
            'product' => $request['product']
            ];

       $broadbands = $this->doSearchingQuery($constraints);
       return view('broadband/index', ['broadbands' => $broadbands, 'searchingVals' => $constraints]);
    }

    private function doSearchingQuery($constraints) {
        $query = Broadband::query();
        $fields = array_keys($constraints);
        $index = 0;
        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $query = $query->where( $fields[$index], 'like', '%'.$constraint.'%');
            }

            $index++;
        }
        return $query->paginate(5);
    }
    private function validateInput($request) {
        $this->validate($request, [
        'product' => 'required|max:60|unique:broadband'
    ]);
    }
}
